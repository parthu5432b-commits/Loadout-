# Loadout — GitHub APK Build Bundle

This is the **repository root** to upload to your private GitHub repository. Do not upload only the inner payload ZIP.

## How the build works

1. GitHub Actions checks out this repository.
2. `scripts/build.mjs` verifies the payload SHA-256.
3. It extracts `payload/loadout-app-payload.zip` into `.build/loadout-app/`.
4. It reads the deeper `BUILD_INSTRUCTIONS.json` from inside the extracted payload.
5. It installs pinned Capacitor dependencies, generates the Android project, installs/registers the Loadout native bridge, syncs `www/`, and runs Gradle `assembleDebug`.
6. Actions uploads the APK as `Loadout-Android-debug-apk`.

The GitHub Actions YAML, build scripts and architecture documents are outside the payload ZIP. Capacitor's `webDir` is `www`, so these repo/build instructions are not copied into the APK as web assets. The native Java bridge is intentionally compiled into the APK.

## Upload this bundle to GitHub

1. Create or open your private `silver-spoon` repository.
2. Extract this outer ZIP on your computer.
3. Upload **the contents inside** the extracted `Loadout-GitHub-Build` folder to the repository root. Do not upload this outer ZIP as one file. The repository root must contain `.github/workflows/build-apk.yml`, `payload/`, `scripts/`, `BUILD_PLAN.json` and `README.md`. Preserve the `.github` directory exactly; without it GitHub will not discover the workflow.
4. Commit/push those files to the `main` or `master` branch. For an existing local clone, copy the extracted contents into the clone, then run `git add .`, `git commit -m "Build Loadout native runtime foundation"` and `git push`.
5. Open **Actions → Build Loadout Android APK**. A push to `main`/`master` starts the workflow automatically; you can also use **Run workflow**.
6. When the run succeeds, open it → **Artifacts** → download `Loadout-Android-debug-apk`. Extract that artifact ZIP to get the `.apk`, then install it on your Android device.

### Keep the signing identity stable (important for preserving app data)

GitHub-hosted runners are disposable. Without a persistent keystore, every run may create a different debug signing certificate. Android will then refuse an in-place update over the previous APK; uninstalling the old app can erase its private data. The workflow supports an optional repository secret named `LOADOUT_DEBUG_KEYSTORE_B64`. Create one persistent debug keystore once, base64-encode it, and save that value as the secret. Use the standard Android debug alias/password (`androiddebugkey` / `android`) so Gradle's debug signing config can use it. This preserves the signing identity for future builds. It cannot recover the private key used to sign an older APK if that key was generated on a previous disposable GitHub runner.

Example (run locally once, keep the keystore private):

```bash
keytool -genkeypair -v -keystore loadout-debug.keystore -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Loadout, OU=Private, O=Loadout, L=Local, S=Local, C=IN"
base64 -w 0 loadout-debug.keystore
```

Copy the resulting base64 string into **GitHub → Settings → Secrets and variables → Actions → New repository secret**. Do not upload the `.keystore` file to the repository.

## Do not change these paths without updating BUILD_PLAN.json

```text
.github/workflows/build-apk.yml   GitHub workflow, build-side only
scripts/build.mjs                 Extracts and reads deep instructions
BUILD_PLAN.json                  Outer build instructions
payload/loadout-app-payload.zip   Actual app payload
payload/SHA256SUMS.txt            Payload integrity check
architecture/                     Full L-SEAA specification
```

## UI and existing data

The original Loadout `www/app.js`, styles, layout, assets and chapter datasets are retained. The runtime bootstrap is loaded before the existing app but adds no visible UI. Existing LocalStorage keys and chat history are not migrated/deleted in this milestone.

## What this build establishes

- Native Android `LoadoutCore` bridge for private file-backed storage and runtime information.
- Five storage lifetimes for new modules: volatile, session, module, TTL and persistent.
- Balanced local diagnostic journal with secret-key redaction.
- Advanced, staged transformation engine for managed configuration and trusted web modules.
- Explicit manual commit/rollback decision API.
- Offline cached runtime bootstrap.

## Important scope boundary

This is the first L-SEAA foundation, not the completed self-evolving platform. Arbitrary DEX/JAR/native `.so` hot loading, a signed private registry, ZIP `.lupdate` import inside the app, a wireless development-port UI, and migration of the old app's storage are not enabled yet. The architecture files identify those next milestones. A new APK is still required for native host/manifest/permission changes.

## Troubleshooting

- **No workflow appears:** ensure `.github/workflows/build-apk.yml` is on the default branch.
- **Payload hash mismatch:** re-upload `payload/loadout-app-payload.zip` and its matching `SHA256SUMS.txt` from the same bundle; do not edit one without regenerating the other.
- **Build says missing BUILD_INSTRUCTIONS.json:** upload the whole outer bundle and keep the payload ZIP intact.
- **Gradle failure:** open the failed job and inspect the first error in the `Extract payload...` step; the build diagnostics artifact is uploaded even on failure when available.
- **APK install conflict:** Android may reject an APK signed with a different debug key than the currently installed app. Uninstalling the previous version can erase app-private data. Export a backup first; do not uninstall until data is protected.

## Local build

Requirements: Node.js 22, JDK 21, Android SDK/platform tools and `unzip`. Run:

```bash
node scripts/build.mjs
```

The generated project is in `.build/loadout-app/`; debug APK is under `android/app/build/outputs/apk/debug/`.
