# Loadout application payload

This folder is the application payload extracted by the outer **Loadout-GitHub-Build** repository workflow. It is not the repository root to upload by itself.

The authoritative upload and APK instructions are in the outer bundle README. The deep build contract is `BUILD_INSTRUCTIONS.json`; the phased architecture and implementation boundaries are in `LOADOUT_ARCHITECTURE.md`.

The Android project is generated during CI from the pinned Capacitor dependencies. The GitHub workflow and build scripts are intentionally kept outside this payload archive. `capacitor.config.json` points to `www/`, so documentation and orchestration files in this payload root are not copied as web assets into the APK.
